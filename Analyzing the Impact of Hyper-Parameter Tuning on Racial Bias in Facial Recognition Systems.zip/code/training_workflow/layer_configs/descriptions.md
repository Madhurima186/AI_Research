
--------------------------------------------------------------------------------
RUN - A
No Flat - 30 EPOCHS - 3 Epoch Patience - No DropOut - Learning Rate 0.001
--------------------------------------------------------------------------------
RUN - B
2 Flat Layers - 30 EPOCHS - 3 Epoch Patience - No DropOut - Learning Rate 0.001
--------------------------------------------------------------------------------
RUN - C
No Flat - 30 EPOCHS - 3 Epoch Patience - No DropOut - Learning Rate 0.0001
--------------------------------------------------------------------------------
RUN - D
No Flat - 30 EPOCHS - 3 Epoch Patience - With DropOut - Learning Rate 0.001
--------------------------------------------------------------------------------
RUN - E
No Flat - 30 EPOCHS - 3 Epoch Patience - With DropOut - Learning Rate 0.0001
--------------------------------------------------------------------------------