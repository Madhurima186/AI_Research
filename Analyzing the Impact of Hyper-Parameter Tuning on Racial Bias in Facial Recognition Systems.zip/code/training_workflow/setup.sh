#!/bin/bash
set -e

pip install --upgrade pip setuptools wheel
pip install -r ./requirements.txt