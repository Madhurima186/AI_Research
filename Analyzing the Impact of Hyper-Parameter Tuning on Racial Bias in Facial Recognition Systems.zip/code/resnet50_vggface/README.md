# Code Source

* Code here is copied from [Github Code](https://github.com/WeidiXie/Keras-VGGFace2-ResNet50/tree/69a608a2a140b7025bcb69adcd2355e38cc89f1d)
* [Weights Installed From](https://drive.google.com/file/d/1AHVpuB24lKAqNyRRjhX7ABlEor6ByZlS/view)
